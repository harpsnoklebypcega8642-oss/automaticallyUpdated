<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:41:"template/default_wap/html/user/login.html";i:1629196480;s:72:"/www/wwwroot/video.fundof.tv/template/default_wap/html/user/include.html";i:1629196480;s:69:"/www/wwwroot/video.fundof.tv/template/default_wap/html/user/foot.html";i:1629196480;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width = device-width ,initial-scale = 1,minimum-scale = 1,maximum-scale = 1,user-scalable =no,"/>
	<title>用户登录 - <?php echo $maccms['site_name']; ?></title>
	<link href="<?php echo $maccms['path_tpl']; ?>css/user.css" type="text/css" rel="stylesheet"/>
<script>var SitePath='{maccms:path}',SiteAid='{maccms:siteaid}',SiteTid='{maccms:sitetid}',SiteId='{maccms:siteid}';</script>
<script src="/static/js/jquery.js"></script>
</head>
<body>
<div class="login-w">
	<!--x返回按钮-->
	<a href="javascript:history.go(-1)" class="btn-close" style="top: 10px;right: 10px;"></a>
	<!--登录-->
	<form method="post" action="">
		<div class="form-group clearfix">
			<i class="i-user"></i>
			<input type="text" name="user_name" placeholder="请输入账号">
		</div>
		<div class="form-group clearfix">
			<i class="i-pwd"></i>
			<input type="password" name="user_pwd" placeholder="请输入密码">
		</div>
		<?php if($GLOBALS['config']['user']['login_verify'] == 1): ?>
		<div class="form-group clearfix">
			<i class="i-img-cod"></i>
			<input type="text" name="verify" class="l_pwd_cod" style="width: 40%;">
			<div class="pwd_img"><img id="verify_img" src="<?php echo url('verify/index'); ?>" onClick="this.src=this.src+'?'+Math.random()" /></div>
		</div>
		<?php endif; ?>
		<input type="button" id="btn_submit" value="立即登录" class="btn-brand">
	</form>
	<div class="log-btn clearfix">
		<a class="btn-white log-reg" href="<?php echo url('user/reg'); ?>">免费注册</a>
		<a class="a-gry" href="<?php echo url('user/findpass'); ?>">找回密码</a>
	</div>
</div>

<!--loading start-->
<div class="loading_box"></div>
<!--loading end-->

<script>

	$("input[name='login_name']").focus();

	$('#btn_submit').click(function(){
		var user_name = $('input[name="user_name"]').val();
		var user_pwd = $('input[name="user_pwd"]').val();
		var verify = $('input[name="verify"]').val();

		if(user_name==''){
			alert('账号不能为空');
			$('input[name="user_name"]').focus();
			return;
		}

		if(user_pwd==''){
			alert('密码不能为空');
			$('input[name="user_pass"]').focus();
			return;
		}

		if($('input[name="verify"]').length>0 && verify==''){
			alert('验证码不能为空');
			$('input[name="verify"]').focus();
			return;
		}

		var data = {user_name:user_name, user_pwd:user_pwd, verify:verify };
		$.ajax({
			url: "<?php echo url('user/login'); ?>",
			type: "post",
			dataType: "json",
			data: data,
			beforeSend: function () {
				//开启loading
				//$(".loading_box").css("display","block");
				$("#btn_submit").css("background","#fd6a6a").val("loading...");
			},
			success: function (r) {
				if(r.code==1){
					location.href="<?php echo url('user/index'); ?>";
				}
				else{
					alert(r.msg);
					$('#verify_img').click();
				}
			},
			complete: function () {
				//结束loading
				//$(".loading_box").css("display","none");
				$("#btn_submit").css("background","#fa4646").val("提交");
			}
		});

	});
</script>
<div class="footer" style="text-align: center;">
	<p>Copyright &copy; 2008-2018 <a class="color" href="http://<?php echo $maccms['site_url']; ?>"><?php echo $maccms['site_name']; ?></a></p>
</div>
</body>
</html>