<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:39:"template/default_wap/html/user/reg.html";i:1629196480;s:72:"/www/wwwroot/video.fundof.tv/template/default_wap/html/user/include.html";i:1629196480;s:69:"/www/wwwroot/video.fundof.tv/template/default_wap/html/user/foot.html";i:1629196480;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width = device-width ,initial-scale = 1,minimum-scale = 1,maximum-scale = 1,user-scalable =no,"/>
	<title>会员注册 - <?php echo $maccms['site_name']; ?></title>
	<link href="<?php echo $maccms['path_tpl']; ?>css/user.css" type="text/css" rel="stylesheet"/>
<script>var SitePath='{maccms:path}',SiteAid='{maccms:siteaid}',SiteTid='{maccms:sitetid}',SiteId='{maccms:siteid}';</script>
<script src="/static/js/jquery.js"></script>
</head>
<body>
<!--子页顶部-->
<div class="zy-search zy-tit">
	<div class="sch-w clearfix">
		<a class="go-back" href="#"><img src="<?php echo mac_url_img($maccms['site_logo']); ?>"></a>
		<div class="tit">
			用户注册
		</div>
	</div>
</div>
<div class="wrap">
	<div class="reg-w">
		<form method="post" id="fm" action="">
			<div class="form-group clearfix">
				<h5>账号</h5>
				<input class="fl" type="text" name="user_name" placeholder="请输入">
			</div>
			<div class="form-group clearfix">
				<h5>密码</h5>
				<input type="password" id="pass1" name="user_pwd" placeholder="请输入">
			</div>
			<div class="form-group clearfix">
				<h5>确认密码</h5>
				<input type="password" id="pass2" name="user_pwd2" placeholder="请输入">
			</div>

			<?php if($user_config['reg_phone_sms'] != 0): ?>
			<input type="hidden" name="ac" value="phone">
			<div class="form-group clearfix">
				<h5>手机号码</h5>
				<input class="fl" type="text" name="to" placeholder="请输入">
				<input type="button" class="fr mr10 mt10" id="btn_send_sms" value="获取验证码"/>
			</div>
			<div class="form-group clearfix">
				<h5>手机验证码</h5>
				<input class="fl" type="text" name="code" placeholder="请输入手机验证码">
			</div>
			<?php elseif($user_config['reg_email_sms'] != 0): ?>
			<input type="hidden" name="ac" value="email">
			<div class="form-group clearfix">
				<h5>邮箱地址</h5>
				<input class="fl" type="text" name="to" placeholder="请输入">
				<input type="button" class="fr mr10 mt10" id="btn_send_sms" value="获取验证码"/>
			</div>
			<div class="form-group clearfix">
				<h5>邮箱验证码</h5>
				<input class="fl" type="text" name="code" placeholder="请输入邮箱验证码">
			</div>
			<?php endif; if($user_config['reg_verify'] != 0): ?>
			<div class="form-group clearfix">
				<h5>验证码</h5>
				<input class="fl" type="text" name="verify" placeholder="请输入">
				<div class="pwd_img"><img id="verify_img" src="<?php echo url('verify/index'); ?>" onClick="this.src=this.src+'?'" /></div>
			</div>
			<?php endif; ?>
			<input type="button" id="btn_submit" class="btn-brand" value="提交">
		</form>
	</div>
</div>

<script>
	$(".go-back").click(function () {
		var ref = document.referrer;
		location.href=ref;
	});

    var countdown=60;
    function settime(val) {
        if (countdown == 0) {
            val.removeAttribute("disabled");
            val.value="获取验证码";
            countdown = 60;
            return true;
        } else {
            val.setAttribute("disabled", true);
            val.value="重新发送(" + countdown + ")";
            countdown--;
        }
        setTimeout(function() {settime(val) },1000)
    }


    $('#btn_send_sms').click(function(){
        var ac = $('input[name="ac"]').val();
        var to = $('input[name="to"]').val();
        if(ac=='email') {
            var pattern = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            var ex = pattern.test(to);
            if (!ex) {
                alert('邮箱格式不正确');
                return;
            }
        }
        else if(ac=='phone') {
            var pattern=/^[1][0-9]{10}$/;
            var ex = pattern.test(to);
            if (!ex) {
                alert('手机号格式不正确');
                return;
            }
        }
        else{
            alert('参数错误');
            return;
        }


        settime(this);
        var data = $("#fm").serialize();

        $.ajax({
            url: "<?php echo url('user/reg_msg'); ?>",
            type: "post",
            dataType: "json",
            data: data,
            beforeSend: function () {
                //开启loading
            },
            success: function (r) {
                alert(r.msg);
            },
            complete: function () {
                //结束loading
            }
        });
    });


	$("#btn_submit").click(function() {
		var data = $('#fm').serialize();
		var input = $("#fm").serializeArray();
		var pass1 = $("#pass1").val();
		var pass2 = $("#pass2").val();
		var inputName = new Array();
		inputName['user_name'] = '账号';
		inputName['user_pwd'] = '密码';
		inputName['user_pwd2'] = '确认密码';
		inputName['user_email'] = '邮箱';
		inputName['verify'] = '验证码';

		var is = false;
		var err = '';
		$.each(input,function(name,field) {
			if (field.value == '' && field.name!='verify') {
				is = true;
				err = inputName[field.name] + '不能为空';
				return false;
			}
		});
		if (is) {
			alert(err);
			return false;
		}
		if (pass1 != pass2) {
			alert('两次密码不一致');
			return false;
		}

		$.ajax({
			url: "<?php echo url('user/reg'); ?>",
			type: "post",
			dataType: "json",
			data: data,
			beforeSend: function () {
				//开启loading
				//$(".loading_box").css("display","block");
				$("#btn_submit").css("background","#fd6a6a").val("loading...");
			},
			success: function (r) {
				alert(r.msg);
				if(r.code==1){
					location.href="<?php echo url('user/login'); ?>";
				}
				else{
					$('#verify_img').click();
				}
			},
			complete: function () {
				//结束loading
				//$(".loading_box").css("display","none");
				$("#btn_submit").css("background","#fa4646").val("提交");
			}
		});
	})
</script>
<div class="footer" style="text-align: center;">
	<p>Copyright &copy; 2008-2018 <a class="color" href="http://<?php echo $maccms['site_url']; ?>"><?php echo $maccms['site_name']; ?></a></p>
</div>
</body>
</html>